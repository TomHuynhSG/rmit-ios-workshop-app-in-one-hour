import SwiftUI

struct ContentView: View {
    // ==========================================
    // 👇 START HERE! (Modify the variables below)
    // ==========================================
    
    // MARK: - STEP 1: PERSONALITY
    // Change the text inside the quotes "" to your own details.
    let myName = "Tom Huynh"
    let myJob = "RMIT Lecturer"
    let myPhone = "0123456789"
    let myEmail = "tom.huynh@rmit.edu.vn"
    
    // The "State" tracks changes on the screen
    @State var currentAnswer = "Tap my face for a Vibe Check..."
    
    var body: some View {
        ZStack {
            // MARK: - STEP 2: BACKGROUND COLOR
            // Try changing .mint to .blue, .purple, .black, or .orange
            Color.mint
                .ignoresSafeArea() // Fills the whole screen
            
            VStack(spacing: 20) {
                Spacer()
                
                // MARK: - STEP 3: THE AVATAR
                // This is a custom view. To change the logic, scroll down to "MagicAvatarView"
                MagicAvatarView(currentAnswer: $currentAnswer)
                
                // MARK: - STEP 4: TEXT STYLING
                // Try changing .bold to .heavy or .thin
                Text(myName)
                    .font(.system(size: 32, weight: .bold))
                
                Text(myJob)
                    .font(.headline)
                    .foregroundColor(.red) // Try changing .red to .white
                
                // MARK: - STEP 5: CONTACT BUTTONS
                // These use the data you typed in Step 1.
                ContactPill(icon: "phone.fill", text: myPhone)
                ContactPill(icon: "envelope.fill", text: myEmail)
                
                // MARK: - STEP 6: HOBBIES
                // ⚠️ To change the hobbies, SCROLL DOWN to the "HobbyList" section!
                HobbyList()
                
                Spacer()
                
                // THE ANSWER BOX
                Text(currentAnswer)
                    .font(.title3)
                    .padding()
                    .background(.black.opacity(0.5))
                    .cornerRadius(15)
                    .foregroundColor(.white)
                
                Spacer()
            }
        }
    }
}

// ==========================================
// ⛔️ STOP SCROLLING! (Unless you are brave)
// The code below is the "Engine Room".
// Only change things here if you want to customize Hobbies or Slang.
// ==========================================

struct ContactPill: View {
    var icon: String
    var text: String
    
    var body: some View {
        RoundedRectangle(cornerRadius: 25)
            .fill(Color.white)
            .frame(width: 280, height: 50)
            .overlay(HStack {
                Image(systemName: icon).foregroundColor(.red)
                Text(text).foregroundColor(.black)
            })
    }
}

// MARK: - STEP 7: CUSTOMIZE HOBBIES
// You can change the icon names (e.g. "star.fill", "heart.fill") and the text.
struct HobbyList: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HobbyRow(icon: "gamecontroller.fill", text: "Gaming")
            HobbyRow(icon: "music.note", text: "Listening to Music")
            HobbyRow(icon: "film.fill", text: "Watching Movies")
            // You can copy and paste the line above to add a 4th hobby!
        }
        .padding()
        .background(Color.white.opacity(0.8))
        .cornerRadius(15)
    }
}

struct HobbyRow: View {
    var icon: String
    var text: String
    var body: some View {
        HStack {
            Image(systemName: icon).foregroundColor(.blue)
            Text(text).foregroundColor(.black)
        }
    }
}

struct MagicAvatarView: View {
    @Binding var currentAnswer: String
    
    // MARK: - STEP 8: GEN Z SLANG DATABASE
    // Add your own phrases inside the quotes!
    let allAnswers = [
        "Bet.", "No cap.", "It's giving... yes.", "Slay.", "That's fire.",
        "Manifesting this.", "The vibes are immaculate.", "Let's get it.",
        "It's giving... nope.", "That's a major L.", "Big yikes.", "I'm not the one.",
        "That's cringe.", "The math ain't mathing.", "It's a no from me.",
        "Vibe check passed.", "Ask again later.", "The rizz is unconfirmed.",
        "Let it cook.", "Main character energy."
    ]
    
    var body: some View {
        ZStack {
            // MARK: - STEP 9: YOUR IMAGE
            // Make sure the name "avatar-picture" matches the file in your Assets
            Image("avatar-picture")
                .resizable()
                .scaledToFit()
                .frame(width: 150)
                .clipShape(Circle())
            
            // This is the crystal ball overlay
            Image("magic-ball-empty")
                .resizable()
                .scaledToFit()
                .frame(width: 250)
        }
        .onTapGesture {
            withAnimation(.spring()) {
                currentAnswer = allAnswers.randomElement()!
            }
        }
    }
}
